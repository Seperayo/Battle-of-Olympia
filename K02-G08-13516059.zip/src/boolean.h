/* File	 		= boolean.h
 * Deskripsi	= mendefinisikan true 1 dan false 0
 * */
 
#ifndef _BOOLEAN_h
#define _BOOLEAN_h

#define boolean unsigned char
#define true 1
#define false 0

#endif
