#ifndef __LOAD_KAR_H_
#define __LOAD_KAR_H_

#include "boolean.h"

#define LMARK '!'
/* State Mesin */
extern char LCC;
extern boolean LEOP;

void LSTART();
void LADV();
#endif
